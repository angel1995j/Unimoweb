<?php
include 'conexion.php';

$id = $_GET['id'];

$sql = "DELETE FROM alumnos WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: index.php?mensaje=Alumno+eliminado+con+éxito");
} else {
    echo "Error: " . $stmt->error;
}
?>
