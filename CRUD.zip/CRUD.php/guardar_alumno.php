<?php
include 'conexion.php';

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$aPaterno = $_POST['aPaterno'];
$aMaterno = $_POST['aMaterno'];
$telefono = $_POST['telefono'];

if ($id) {
    // Actualizar alumno existente
    $sql = "UPDATE alumnos SET nombre=?, aPaterno=?, aMaterno=?, telefono=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $nombre, $aPaterno, $aMaterno, $telefono, $id);
} else {
    // Insertar nuevo alumno
    $sql = "INSERT INTO alumnos (nombre, aPaterno, aMaterno, telefono) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nombre, $aPaterno, $aMaterno, $telefono);
}

if ($stmt->execute()) {
    header("Location: index.php?mensaje=Alumno+guardado+con+éxito");
} else {
    echo "Error: " . $stmt->error;
}
?>
