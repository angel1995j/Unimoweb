<?php include 'conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Alumnos</title>
</head>
<body>
    <h2>Agregar/Editar Alumno</h2>
    <form method="POST" action="guardar_alumno.php">
        <input type="hidden" name="id" value="<?= $_GET['id'] ?? '' ?>">
        <label>Nombre:</label><br>
        <input type="text" name="nombre" required value="<?= $_GET['nombre'] ?? '' ?>"><br>
        <label>Apellido Paterno:</label><br>
        <input type="text" name="aPaterno" required value="<?= $_GET['aPaterno'] ?? '' ?>"><br>
        <label>Apellido Materno:</label><br>
        <input type="text" name="aMaterno" required value="<?= $_GET['aMaterno'] ?? '' ?>"><br>
        <label>Teléfono:</label><br>
        <input type="text" name="telefono" value="<?= $_GET['telefono'] ?? '' ?>"><br><br>
        <button type="submit">Guardar</button>
    </form>
    <a href="index.php">Regresar</a>
</body>
</html>
