<?php
$host = "localhost"; //casi siempre será localhost
$user = "woo_usuarioEjemplo"; // usuario de tu base de datos
$password = "NqDXZyxkKGvw"; // contraseña de tu base de datos
$dbname = "woo_ejemplo"; // nombre que le pusiste a la base de datos

$conn = new mysqli($host, $user, $password, $dbname); //aqui se hace la conexión con la base de datos

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error); // si por alguna razon no se conecta saldrá este mensaje
}
?>
