<?php
// Obtén los números del formulario
    $numero1 = $_POST['numero1'];
    $numero2 = $_POST['numero2'];

    // Suma los números
    $resultado = $numero1 + $numero2;

    // Muestra el resultado en un h1
    echo "<h1>El resultado de la suma es: $resultado</h1>";
    
    // Evalua si es mayor a 10
    if($resultado > 10){
         echo "<h1>El resultado de mayor a 10 </h1>";
    }else{
        echo "<h1>El resultado de menor a 10 </h1>";
    }

?>
