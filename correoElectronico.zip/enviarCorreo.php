<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger los datos del formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $asunto = $_POST['asunto'];
    $mensaje = $_POST['mensaje'];
    
    // Configurar destinatario y asunto
    $destinatario = "MiCorreo@gmail.com";  // Cambia esto por el correo de destino
    $asuntoCorreo = "Correo recibido deste tu página web";

    // Crear el mensaje del correo
    $mensajeCorreo = "Nombre: $nombre\n";
    $mensajeCorreo .= "Correo Electrónico: $email\n";
    $mensajeCorreo .= "Mensaje:\n$mensaje\n";

    // Cabeceras del correo
    $cabeceras = "From: $email\r\n";
    $cabeceras .= "Reply-To: $email\r\n";

    // Enviar el correo
    if (mail($destinatario, $asuntoCorreo, $mensajeCorreo, $cabeceras)) {
        echo "Correo enviado con éxito.";
    } else {
        echo "Hubo un problema al enviar el correo.";
    }
} else {
    echo "Método no permitido.";
}
?>
