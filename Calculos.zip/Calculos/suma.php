<?php
 // Obtener los números del formulario
    $numero1 = $_POST['numero1'];
    $numero2 = $_POST['numero2'];
    
    // Realizar la suma
    $resultado = $numero1 + $numero2;
    
    // Mostrar el resultado
    echo "<h1>Resultado de la Suma</h1>";
    echo "<p>Número 1: $numero1</p>";
    echo "<p>Número 2: $numero2</p>";
    echo "<p>Suma: $resultado</p>";
?>
